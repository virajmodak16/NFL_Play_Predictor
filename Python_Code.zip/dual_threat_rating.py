# -*- coding: utf-8 -*-
"""
Created on Fri Oct 25 09:25:46 2019

@author: vpmodak
"""

import pandas as pd
import os

def dual_threat_rating(QB_data, QB_IDs):
    """
    This function calculates a quarterback dual threat rating which will be used to calculate dual
    threat rating of a quarter-back which can potentially influence a play
    
    """
    
    #implement a run filter so that we can extract QB run plays
    run_filter = (QB_data['play_type'] == 'run') &  (QB_data['rusher_player_id'].isin(QB_IDs['gsis_id'].tolist()))
    QB_run = QB_data[run_filter]
    
    #change data type of yards gained to float
    QB_run['yards_gained'] = QB_run['yards_gained'].astype(float)
    
    # get the QB total Run yards for each game
    QB_run_yards_for_game = QB_run.groupby(['rusher_player_id']).agg({'yards_gained': 'sum', 'play_type': 'count', 'game_id':lambda x: x.nunique()})
    QB_run_yards_for_game.columns = ['total_yards_gained','run_attempts','games_run_in']
    QB_run_yards_for_game['dual_threat_factor'] = (QB_run_yards_for_game['total_yards_gained']*QB_run_yards_for_game['run_attempts'])/(QB_run_yards_for_game['games_run_in']**2)
    QB_run_yards_for_game = QB_run_yards_for_game.reset_index()
    QB_run_yards_for_game['player_name'] = QB_run_yards_for_game['rusher_player_id']\
                                    .apply(lambda x: QB_IDs.loc[QB_IDs['gsis_id'] == x, 'abbr_player_name'].iloc[0])
    sz = QB_run_yards_for_game['dual_threat_factor'].size-1
    QB_run_yards_for_game['dual_threat_percentile'] = QB_run_yards_for_game['dual_threat_factor'].rank(method='max').apply(lambda x: 1.0*(x-1)/sz)
    
    return QB_run_yards_for_game