# -*- coding: utf-8 -*-
"""
Created on Fri Oct 25 09:25:46 2019

@author: vpmodak
"""

import pandas as pd
import os

def dual_threat_rating(QB_data, QB_IDs):
    #filter for null passer data
    QB_filter = QB_data['passer_player_id'] != 'NA'
    
    #extract QB IDs
    QB_IDs = QB_data[QB_filter][['passer_player_name','passer_player_id']] \
                                .drop_duplicates(subset='passer_player_id') \
                                .sort_values(by='passer_player_name') \
                                .reset_index()
    
    #implement a run filter so that we can extract QB run plays
    run_filter = (QB_data['play_type'] == 'run') &  (QB_data['rusher_player_id'].isin(QB_IDs['passer_player_id'].tolist()))
    QB_run = QB_data[run_filter]
    
    #change data type of yards gained to float
    QB_run['yards_gained'] = QB_run['yards_gained'].astype(float)
    
    # get the QB total Run yards for each game
    QB_run_yards_for_game = QB_run.groupby(['rusher_player_id']).agg({'yards_gained': 'sum', 'play_type': 'count', 'game_id':lambda x: x.nunique()})
    QB_run_yards_for_game.columns = ['total_yards_gained','run_attempts','games_run_in']
    QB_run_yards_for_game['yards_per_game'] = QB_run_yards_for_game['total_yards_gained']/QB_run_yards_for_game['games_run_in']
    return 'dummy'