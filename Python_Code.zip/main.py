# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 15:46:48 2019

@author: vpmodak
"""


import pandas as pd
import glob
import os
from data_clean_up import data_clean_up
from play_clock import play_clock
from pass_performance import pass_performance
from run_performance import run_performance
from dual_threat_rating import dual_threat_rating
from team_dual_threat import team_dual_threat

homepath = r"C:\\Users\\vpmodak\\Desktop\\Personal\\Springboard\\NFL Play Predictor\\Data"
os.chdir(homepath)
df_raw = pd.DataFrame()
roster_raw = pd.DataFrame()

#Create player roster
for file in glob.glob('*roster*.csv'):
    player_yearwise = pd.read_csv(file, dtype = str, keep_default_na=False) #read all the data as list
    roster_raw = roster_raw.append(player_yearwise)
print('Roster data read successfully with shape {}'.format(roster_raw.shape))

#filter out QBs from the cumulative roster
roster_QB = roster_raw[roster_raw['position'] == 'QB'].drop_duplicates(subset='gsis_id').sort_values(by = 'full_player_name')

### Read all play data
for file in glob.glob('reg*pbp*.csv'):
    df_yearwise = pd.read_csv(file, dtype = str, keep_default_na=False) #read all the data as list
    if 'touchback' in df_yearwise.columns:
        df_yearwise = df_yearwise.drop(columns=['touchback']) # drop extra 'touchback' column for consistency
    df_raw = df_raw.append(df_yearwise)
    print('{} read successfully with shape {}'.format(file, df_yearwise.shape))


# Create a separate dataframe with relevant features
print('Cleaning up data now')
df_full_raw = data_clean_up(df_raw) # quick clean-up of data. Remove Timeout, 2-min warning and END game/qtr
df_full = df_full_raw[(df_full_raw['play_type'] == 'pass') | (df_full_raw['play_type'] == 'run')].reset_index(drop=True)
print('Preliminary data clean-up done. Proceeding to extract relevant parameters')

# extract basic parameters data
df_final = df_full[['game_id','posteam','defteam','qtr','desc','down','ydstogo', 'posteam_timeouts_remaining','score_differential']]
print('Basic parameters extracted. Proceeding to extract play-clock information')

# get the value of play clock for each of the plays
df_final['play_clock'] = play_clock(df_full[['qtr','time']])


# get the yards to goal for each of the plays
print('Proceeding to extract distance to goal')
df_final['yards_to_goal'] = df_full['yardline_100']


# run function to get cumulative pass completion percentage and the cumulative pass yardage at start of every play
print('Proceeding to extract pass performance')
df_final['cum_pass_comp%'], df_final['cum_pass_yards'] = pass_performance(df_full)

#run function to get the cumulative run yards at start of every play
print('Proceeding to extract run performance')
df_final['cum_run_yards'] = run_performance(df_full)

#get QB dual threat rating
print('Proceeding to extract Team dual threat rating')
QB_dual_threat = dual_threat_rating(df_full, roster_QB)

#get the dual threat rating for the team based on each game
df_final['teamQB_dual_threat_rating'] = team_dual_threat(df_full, QB_dual_threat)
df_final['play_type'] = df_full['play_type']
print('Full data cleanup and extraction successful. Final shape of the matrix:')
print(df_final.shape)

df_final.to_csv('FINAL_PBP_DATA.csv', index=False)