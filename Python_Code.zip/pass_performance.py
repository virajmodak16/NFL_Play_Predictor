# -*- coding: utf-8 -*-
"""
Created on Mon Oct 21 15:00:20 2019

@author: vpmodak
"""


import pandas as pd
import glob
import os
from collections import defaultdict
import numpy as np

def pass_performance(df_pass):
    
    """ 
    This function takes in the parent dataframe and then calculates the the cumulative pass completion percentage
    and the cumulative yeardage for the game for the passing team
    
    """
    
    df_pass['pass_yards'] = pd.to_numeric(df_pass['complete_pass'], errors='coerce')*pd.to_numeric(df_pass['yards_gained'], errors='coerce')
    df_pass['cum_pass_attempt'] = df_pass.groupby(['game_id', 'posteam'])['pass_attempt'].apply(lambda x: pd.to_numeric(x, errors='coerce').cumsum())
    df_pass['cum_pass_comp'] = df_pass.groupby(['game_id', 'posteam'])['complete_pass'].apply(lambda x: pd.to_numeric(x, errors='coerce').cumsum())
    df_pass['cum_pass_comp%'] = (df_pass['cum_pass_comp']/df_pass['cum_pass_attempt']).fillna(0)
    df_pass['cum_pass_yards'] = df_pass.groupby(['game_id', 'posteam'])['pass_yards'].apply(lambda x: pd.to_numeric(x, errors='coerce').cumsum())
    
    return df_pass['cum_pass_comp%'], df_pass['cum_pass_yards']