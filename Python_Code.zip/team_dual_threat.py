# -*- coding: utf-8 -*-
"""
Created on Tue Oct 29 16:41:33 2019

@author: vpmodak
"""

import pandas as pd
import os
from collections import defaultdict

def team_dual_threat(df_QB, QB_dual_threat):   
    
    def wavg(group):
        player_count = group['count']
        rating = group['dual_threat_rating']
        return (player_count*rating).sum()/player_count.sum()
    
    def f(x):    
        return dual_threat_grouped[x['game_id']][x['posteam']]

    dual_threat_dict = dict(zip(QB_dual_threat.rusher_player_id, QB_dual_threat.dual_threat_percentile))
    dual_threat_defdict = defaultdict(lambda: 0, dual_threat_dict)
    
    df_QB_filtered = df_QB[(df_QB['play_type'] == 'pass')]
    pass_count = df_QB_filtered.groupby(['game_id', 'posteam','passer_player_id']).agg({'passer_player_id' : 'count'})
    pass_count.columns = ['count']
    pass_count = pass_count.reset_index()
    pass_count['dual_threat_rating'] = pass_count['passer_player_id'].map(dual_threat_defdict)
    dual_threat_grouped = pass_count.groupby(['game_id', 'posteam']).apply(wavg)
    df_QB['dual_threat_rating'] = df_QB.apply(f, axis=1)
    return df_QB['dual_threat_rating']