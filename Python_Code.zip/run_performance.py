# -*- coding: utf-8 -*-
"""
Created on Tue Oct 22 15:27:05 2019

@author: vpmodak
"""

import pandas as pd
import glob
import os
from collections import defaultdict
import numpy as np

def run_performance(df_run):
    
    """ 
    This function takes in the parent dataframe and then calculates the the cumulative run/rush
    yardage for the offensive team for that particular game
    
    """
    
    df_run['run_yards'] = df_run.loc[df_run['play_type'] == 'run', 'yards_gained']
    df_run['run_yards'] = df_run['run_yards'].fillna(0)
    df_run['cum_run_yards'] = df_run.groupby(['game_id', 'posteam'])['run_yards'].apply(lambda x: pd.to_numeric(x, errors='coerce').cumsum())
    return df_run['cum_run_yards']