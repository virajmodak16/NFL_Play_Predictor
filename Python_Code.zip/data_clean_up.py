# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 15:51:15 2019

@author: vpmodak
"""

import pandas as pd
import re
import numpy as np

def data_clean_up(df_year):
    """
    This function essentially cleans up the full raw data file and removes all the entries which are not 
    
    relevant plays, like timeouts, end of game/quarters, game suspensions and resumptions and other entries 
    
    which were noticed during data wrangling
    
    """
    df_year = df_year[~df_year.desc.str.startswith("Timeout")].reset_index(drop = True) # remove Timeout plays
    df_year = df_year[~df_year.desc.str.startswith("Two-Minute")].reset_index(drop = True) # remove 2-minute warning plays
    df_year = df_year[~df_year.desc.str.startswith("END")].reset_index(drop = True) # remove END qtr/game plays
    df_year = df_year[~df_year.desc.str.startswith("End")].reset_index(drop = True) # remove End qtr/game plays
    df_year = df_year[~df_year.desc.str.startswith("The game has been suspended")].reset_index(drop = True) # remove End qtr/game plays
    df_year = df_year[~df_year.desc.str.startswith("The game has resumed")].reset_index(drop = True)
    df_year = df_year[~df_year.desc.str.startswith("Raider Captains: ")].reset_index(drop = True)    
    df_year['time'].replace('', np.nan, inplace=True) # remove blank plays
    df_year = df_year.dropna(subset=['time']).reset_index(drop=True)
    return df_year