# -*- coding: utf-8 -*-
"""
Created on Thu Oct 17 16:22:47 2019

@author: vpmodak
"""

def play_clock(df_play_clock_trunc):
    
    """ 
    This function takes in quarter and time from the main function and 
    
    calculates the net minutes remaining in the game    
    
    """
    
    time_dict = {'1':45, '2':30, '3':15, '4': 0}
    split_time = df_play_clock_trunc.time.str.split(':', n = 1, expand = True)
    df_play_clock_trunc['minutes'] = split_time[0].astype(float)
    df_play_clock_trunc['seconds'] = split_time[1]
    split_time2 = df_play_clock_trunc.seconds.str.split(':', n = 1, expand = True)    
    df_play_clock_trunc['seconds_2'] = split_time2[0].astype(float)
    df_play_clock_trunc['qtr2mins_rem'] = df_play_clock_trunc['qtr'].map(time_dict)
    df_play_clock_trunc['net_mins_remaning'] = df_play_clock_trunc['qtr2mins_rem'] + df_play_clock_trunc['minutes'] + df_play_clock_trunc['seconds_2']/60
    
    return df_play_clock_trunc['net_mins_remaning']